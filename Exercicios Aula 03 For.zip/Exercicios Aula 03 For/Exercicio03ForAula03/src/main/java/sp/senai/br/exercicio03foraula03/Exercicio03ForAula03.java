
package sp.senai.br.exercicio03foraula03;

import javax.swing.JOptionPane;

public class Exercicio03ForAula03 {
    
    public static void main(String[] args) {
        int contador = 1;
        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o numero para saber seus divisores"));
          for(int i = num; i>0;i--){//não pode fazer divisoes com zero
            if(num%i==0){
                
                System.out.println("Divisor "+contador+": "+i);
                contador++;
            }
    }
    }
}
