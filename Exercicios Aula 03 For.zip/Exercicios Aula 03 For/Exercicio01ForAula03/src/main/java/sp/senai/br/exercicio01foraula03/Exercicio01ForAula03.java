
package sp.senai.br.exercicio01foraula03;

import javax.swing.JOptionPane;

public class Exercicio01ForAula03 {

    public static void main(String[] args) {
        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um numero para ver sua tabuada até o 10:"));
        for(int i = 0; i<=10; i++){
            System.out.println(num +" X "+ i + " = " + (i * num));
        }
}
}
