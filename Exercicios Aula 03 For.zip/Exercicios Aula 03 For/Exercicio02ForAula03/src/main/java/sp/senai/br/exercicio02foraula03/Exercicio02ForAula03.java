package sp.senai.br.exercicio02foraula03;

import javax.swing.JOptionPane;

public class Exercicio02ForAula03 {
    
    public static void main(String[] args) {
        int result = 0;
        for (int i = 0; i <= 5; i++) {
            int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o num"));
            float div = num % 2;
            if (div > 0) {
                
                result = result + num;
                
            }
        }
        JOptionPane.showMessageDialog(null, "A soma dos numeros impares digitados é igual a: " + result);
    }
}
//Solicite para o usuário 5 números inteiros e some apenas os números impares.
