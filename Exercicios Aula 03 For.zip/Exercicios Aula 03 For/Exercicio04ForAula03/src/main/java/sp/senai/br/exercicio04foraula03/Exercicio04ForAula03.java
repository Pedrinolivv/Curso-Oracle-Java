
package sp.senai.br.exercicio04foraula03;

import java.time.Year;
import java.util.Calendar;
import javax.swing.JOptionPane;


public class Exercicio04ForAula03 {

    public static void main(String[] args) {
        int result = 0;
        for (int i =1; i<11; i++){
            int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano de nascimento da "+i+"° pessoa"));
            if ((2024 - idade) > 18){
                result++;
            }
          
        }
         JOptionPane.showMessageDialog(null, "a quantidade de pessoas que são maiores de idade são: "+result);
}
}