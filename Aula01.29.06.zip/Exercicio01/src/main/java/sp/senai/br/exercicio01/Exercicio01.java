

package sp.senai.br.exercicio01;

import javax.swing.JOptionPane;

public class Exercicio01 {

    public static void main(String[] args) {
        String sNome = JOptionPane.showInputDialog("Digite seu nome:");
        int iIdade = Integer.parseInt(JOptionPane.showInputDialog("Digite seu nome:"));
        float fAltura = Float.parseFloat(JOptionPane.showInputDialog("Digite seu nome:"));
        
        JOptionPane.showMessageDialog(null, "Olá "+sNome+", a sua idade é: "+iIdade+", e a sua altura é: "+fAltura);
        
                
    }
}
