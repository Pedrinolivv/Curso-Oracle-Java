
package sp.senai.br.aula1;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Aula1 {

    public static void main(String[] args) {
        String snomeCompleto = "Pedro de Oliveira Marçal";
        int iIdade = 17;
        float fAltura = 1.70f; 
        System.out.println(snomeCompleto+" "+iIdade+" "+fAltura);
      
        System.out.println("Hello World!");
        Scanner scanner = new Scanner(System.in);
        String nome = scanner.nextLine();
        int iconta = 0;
        JOptionPane.showMessageDialog(null, "Calculadora de dois numeros "+nome);
        int n1 = Integer.parseInt(JOptionPane.showInputDialog("Qual o numero meu chapa?"));
        int n2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o 2° numero meu chapa"));
        String operador = JOptionPane.showInputDialog(null, "Qual o numerador da conta chapa? + . - . / . *");
        if(operador.equals("+")){
            iconta = n1 + n2;
            JOptionPane.showMessageDialog(null, "O resultado da conta do "+n1+" "+operador+" "+n2+" é igual a: "+iconta);
        }
        else if (operador.equals("-")){
            iconta = n1 - n2;
            JOptionPane.showMessageDialog(null, "O resultado da conta do "+n1+" "+operador+" "+n2+" é igual a: "+iconta);
        }
        else if (operador.equals("/")){
            if(n1 > n2){
                float fconta = n1 / n2;
                JOptionPane.showMessageDialog(null, "O resultado da conta do "+n1+" "+operador+" "+n2+" é igual a: "+fconta);
            }else{
                JOptionPane.showMessageDialog(null, "Essa conta não pode acontecer, pois o seu n1 é maior q n2");
            }
        }    
        else if (operador.equals("*")){
            iconta = n1 * n2;
            JOptionPane.showMessageDialog(null, "O resultado da conta do "+n1+" "+operador+" "+n2+" é igual a: "+iconta);
        }
        
    }
    
}
