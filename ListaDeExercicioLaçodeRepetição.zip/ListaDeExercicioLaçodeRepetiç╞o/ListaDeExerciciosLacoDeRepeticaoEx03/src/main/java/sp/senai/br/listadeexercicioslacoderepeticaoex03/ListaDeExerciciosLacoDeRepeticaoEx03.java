package sp.senai.br.listadeexercicioslacoderepeticaoex03;

import javax.swing.JOptionPane;

public class ListaDeExerciciosLacoDeRepeticaoEx03 {

    public static void main(String[] args) {
        //Usando a rotina de repetição “for”, faça um programa que leia 10 números e mostre a média aritmética dos valores lidos.
        //Obs: O programa não deverá aceitar valores de “entrada” negativos ou iguais a 0 (zero), portanto
        //O programa deverá testar todos os valores de “entrada”.
        int soma = 0;

        for (int i = 1; i <= 10; i++) {
            int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + i + "° num"));
            soma = soma + num;

        }
        float media = 0;
        media = soma / 10;
        JOptionPane.showMessageDialog(null, "A soma dos numeros é igual a: " + soma + " E a meidia desses numeros é igual a: " + media);
    }
}
