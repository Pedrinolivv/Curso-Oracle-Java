
package sp.senai.br.listadeexercicioslacoderepeticaoex04;

import javax.swing.JOptionPane;

public class ListaDeExerciciosLacoDeRepeticaoEx04 {

    public static void main(String[] args) {
       //Faça um programa que leia quatro notas (números reais) de um aluno, calcule e mostre a média (aritmética) final do aluno e uma mensagem
       //informando se o aluno está ou não aprovado, considerando uma média final igual ou superior a seis para a aprovação.
       //Obs1: O programa não deverá aceitar valores de “entrada” negativos ou superiores a 10 (dez), portanto
       //O programa deverá testar todos os valores de “entrada”.
       float soma = 0;
       for ( int i = 1; i <= 4; i++){ 
           float fNota = Float.parseFloat(JOptionPane.showInputDialog("Digite a "+i+"° nota"));
           if (fNota > 10){
              JOptionPane.showMessageDialog(null, "A nota deve ser menor que 10"); 
              i--;
            }else if (fNota > 0){
              soma = soma + fNota;
            }else if (fNota == 0){
               JOptionPane.showMessageDialog(null, "A nota deve ser maior que 0"); 
              i--; 
            }
       }
       float media = soma / 4;
       if(media >= 6){
           JOptionPane.showMessageDialog(null, "O aluno está aprovado! Com uma média de: "+media+"pts.");
       } else if (media < 6){
           JOptionPane.showMessageDialog(null, "O aluno está reprovado! Com uma média de: "+media+"pts.");
       }
    }
}
