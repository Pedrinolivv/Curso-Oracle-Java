
package sp.senai.br.listadeexercicioslacoderepeticaoex05;

import javax.swing.JOptionPane;

public class ListaDeExerciciosLacoDeRepeticaoEx05 {

    public static void main(String[] args) {
       //Faça um programa que leia um número real para o saldo de uma conta bancária, em seguida o programa deverá ler dez valores.
       //Para cada valor lido, o programa deverá perguntar ao usuário se o lançamento é um crédito ou um débito, ao final
       //o programa deverá mostrar o total de créditos e o total de débitos lançados, assim como o saldo atual da conta corrente.
        //Obs1: O programa não deverá aceitar valores de “entrada” negativos ou iguais a 0 (zero), portanto
        //o programa deverá testar todos os valores de “entrada”.
        //Obs2: O programa deverá repetir a sua execução, enquanto o usuário assim o desejar.
        
        float fSaldo = Float.parseFloat(JOptionPane.showInputDialog("Digite o saldo da conta bancaria:"));
        int creditos = 0, debitos =0;
        
        for (int i = 1; i < 10; i++){
            float valor = Float.parseFloat(JOptionPane.showInputDialog("Digite o "+i+"° valor:"));
            if (valor < 0 ){
                JOptionPane.showMessageDialog(null, "O valor deve ser maior que 0");
                i--;
            }
            int escolha = Integer.parseInt(JOptionPane.showInputDialog(null, "Credito(Digite 1) ou Debito(Digite 2)?:"));
            if (escolha == 1){
                fSaldo = fSaldo + valor;
                JOptionPane.showMessageDialog(null, "O valor "+valor+" foi Creditado na conta! Saldo atual: "+fSaldo);
                creditos ++;
                       
            } else if ( escolha == 2 ){
                 fSaldo = fSaldo - valor;
                 JOptionPane.showMessageDialog(null, "O valor "+valor+" foi Debitado na conta! Saldo atual: "+fSaldo);
                 debitos ++;
                 
            } else {
                JOptionPane.showMessageDialog(null, "O valor de Escolha deve ser entre 1(Credito) e 2 (Debito ");
                i--;
            }
        }
        JOptionPane.showMessageDialog(null, "O valor final do saldo foi de: "+fSaldo+", com um total de "+creditos+" creditos, e de "+debitos+" debitos.");
        
    }
}
