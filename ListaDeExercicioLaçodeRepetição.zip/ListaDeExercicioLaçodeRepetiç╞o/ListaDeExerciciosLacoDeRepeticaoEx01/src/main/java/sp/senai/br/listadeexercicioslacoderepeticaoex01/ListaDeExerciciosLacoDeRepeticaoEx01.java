
package sp.senai.br.listadeexercicioslacoderepeticaoex01;

import javax.swing.JOptionPane;

public class ListaDeExerciciosLacoDeRepeticaoEx01 {

    public static void main(String[] args) {
        //Usando a rotina de repetição “for”, faça um programa que leia 10 números e mostre qual o maior número lido.
        //Obs: O programa não deverá aceitar valores de “entrada” negativos ou iguais a 0 (zero), portanto
        //O programa deverá testar todos os valores de “entrada”.
        int maior = 0; 
        
         for (int i = 1; i <= 10; i++){
             int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o "+i+"° num"));
             if(num > maior){
                 maior = num;
             }
         }
         JOptionPane.showMessageDialog(null, "O maior numero digitado foi "+maior);
    }
  }

