

package sp.senai.br.exercicio05aula02;

import java.time.Year;
import javax.swing.JOptionPane;

public class Exercicio05Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Digite um ano e descubra se ele é bixesto");
        float fAno = Float.parseFloat(JOptionPane.showInputDialog("Digite o ano:"));
        if (Year.isLeap((long) fAno) == true){
            JOptionPane.showMessageDialog(null, "O ano "+ fAno +" É bissexto ");
        }  else {
            JOptionPane.showMessageDialog(null, "O ano " + fAno + " Não é Bissexto");
        }
    }
}