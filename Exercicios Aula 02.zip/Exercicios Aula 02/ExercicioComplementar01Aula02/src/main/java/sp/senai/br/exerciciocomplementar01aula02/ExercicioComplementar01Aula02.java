
package sp.senai.br.exerciciocomplementar01aula02;

import javax.swing.JOptionPane;

public class ExercicioComplementar01Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Verifique se um número é positivo, menor que 100, E não é zero.");
        float num = Float.parseFloat(JOptionPane.showInputDialog("Digite o numero:"));
        if (num > 0 && num < 100 && num != 0){
            JOptionPane.showMessageDialog(null, "O numero é valido");
        } else {
            JOptionPane.showMessageDialog(null, "Seu numero não é valido");
        }
    }
}
