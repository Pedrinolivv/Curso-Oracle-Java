
package sp.senai.br.exercicio02aula02;

import javax.swing.JOptionPane;

public class Exercicio02Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Par ou Impar?");
        float num = Float.parseFloat(JOptionPane.showInputDialog("Digite o numero:"));
        if(num % 2 == 0 ){
            JOptionPane.showMessageDialog(null, "seu numero é Par");
        } else {
            JOptionPane.showMessageDialog(null, "Seu numero é Impar");
        }
    }
}