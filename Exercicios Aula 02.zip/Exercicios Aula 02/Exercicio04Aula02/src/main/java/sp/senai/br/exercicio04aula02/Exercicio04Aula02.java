
package sp.senai.br.exercicio04aula02;

import javax.swing.JOptionPane;

public class Exercicio04Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Digite os lados do triangulo e veja se ele é equilátero (três lados iguais), isósceles (dois lados iguais) ou escaleno (nenhum lado igual).");
        float l1 = Float.parseFloat(JOptionPane.showInputDialog("Valor dp 1° Lado:"));
        float l2 = Float.parseFloat(JOptionPane.showInputDialog("Valor dp 2° Lado:"));
        float l3 = Float.parseFloat(JOptionPane.showInputDialog("Valor dp 3° Lado:"));
        if (l1 != l2 && l1 != l3){
            JOptionPane.showMessageDialog(null, "O seu triangulo é escaleno pois tem os lados diferentes ");  
        } else if (l1 == l2 && l1 != l3) {
            JOptionPane.showMessageDialog(null, "O seu triangulo é isósceles, pois tem 2 lados iguais e 1 diferente");
        } else if (l1 == l3 && l1 != l2){
            JOptionPane.showMessageDialog(null, "O seu triangulo é isósceles, pois tem 2 lados iguais e 1 diferente");
        } else if ( l1 == l2 && l1 == l3 && l3 == l2){
            JOptionPane.showMessageDialog(null, "O seu triangulo é equilátero, pois todos os lados são iguais");
        }
    }
}
