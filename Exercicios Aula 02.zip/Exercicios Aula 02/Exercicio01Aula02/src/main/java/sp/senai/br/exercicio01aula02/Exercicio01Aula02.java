
package sp.senai.br.exercicio01aula02;

import javax.swing.JOptionPane;


public class Exercicio01Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Digite um número e descubra se ele é positivo negativo ou zero");
        float num = Float.parseFloat(JOptionPane.showInputDialog("Digite um numero:"));
        if (num > 0){
           JOptionPane.showMessageDialog(null, "O seu número é Positivo");
        } else if (num < 0){
            JOptionPane.showMessageDialog(null, "O seu numero é negativo");
        } else {
            JOptionPane.showMessageDialog(null, "Seu numero é igual a zero");
        }
    }
}
