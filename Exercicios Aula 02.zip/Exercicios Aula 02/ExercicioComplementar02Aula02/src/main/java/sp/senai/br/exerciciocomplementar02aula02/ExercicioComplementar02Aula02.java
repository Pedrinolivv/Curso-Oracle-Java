

package sp.senai.br.exerciciocomplementar02aula02;

import javax.swing.JOptionPane;

public class ExercicioComplementar02Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Digite as notas no trabalho e na prova");
        float fProva = Float.parseFloat(JOptionPane.showInputDialog("Digite a nota do aluno na prova:"));
        float fTrab = Float.parseFloat(JOptionPane.showInputDialog("Digite a nota desse aluno no trabalho"));
        if (fProva >= 60 && fTrab > 70 || fProva == 100 && fTrab == 100){
            JOptionPane.showMessageDialog(null, "O aluno está aprovado!");
        } else { 
            JOptionPane.showMessageDialog(null, "O aluno foi reprovado");
        }
    }
}
