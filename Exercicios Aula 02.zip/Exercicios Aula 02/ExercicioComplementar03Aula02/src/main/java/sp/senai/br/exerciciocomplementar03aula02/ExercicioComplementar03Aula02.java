
package sp.senai.br.exerciciocomplementar03aula02;

import javax.swing.JOptionPane;

public class ExercicioComplementar03Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Calculadora de Imc ");
        float peso = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor do peso em kg:"));
        float altura = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor da altura em m"));
        float imc = peso/(altura*altura);
        if (imc < 18.5){
            JOptionPane.showMessageDialog(null,  "Você está Abaixo do peso com um Imc de "+imc);
        } else if (imc > 24.99){
            JOptionPane.showMessageDialog(null, "Você está com seu peso normal com um Imc de "+imc);
        } else if (imc > 29.99){
            JOptionPane.showMessageDialog(null, "Você está com sobrePeso com um Imc de "+ imc);
        } else if (imc < 30.00) {
            JOptionPane.showMessageDialog(null, "Você esta com Obesidade com um Imc de "+imc);
        }
    }
}
