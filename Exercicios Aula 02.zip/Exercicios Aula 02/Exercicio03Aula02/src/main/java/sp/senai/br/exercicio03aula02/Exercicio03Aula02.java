
package sp.senai.br.exercicio03aula02;

import javax.swing.JOptionPane;

public class Exercicio03Aula02 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Qual o maior numero?");
        float n1 = Float.parseFloat(JOptionPane.showInputDialog("Digite o 1° numero"));
        float n2 = Float.parseFloat(JOptionPane.showInputDialog("Digite o 2° numero"));
        float n3 = Float.parseFloat(JOptionPane.showInputDialog("Digite o 3° numero"));
        if (n1 > n2 && n1 > n3){
            JOptionPane.showMessageDialog(null, "O 1° numero é maior com o valor de "+n1);
        } else if (n2 > n1 && n2 > n3){
            JOptionPane.showMessageDialog(null, "O 2° numero é o maior com o valor de "+n2);
        } else if (n3 > n1 && n3 > n2){
            JOptionPane.showMessageDialog(null, "O 3° numero é o maior com o valor de "+n3);
        }
    }
}