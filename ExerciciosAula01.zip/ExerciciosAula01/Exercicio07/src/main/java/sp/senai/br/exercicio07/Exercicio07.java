/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio07;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio07 {

    public static void main(String[] args) {
        float valor = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor do produto:"));
        float prctg = Float.parseFloat(JOptionPane.showInputDialog("O valor da porcentagem a ser aplicada?"));
        float valorFinal = valor*(100-prctg)/100;
        JOptionPane.showMessageDialog(null, "O Valor final do produto com "+prctg+"% de desconto é de: "+valorFinal);
        
    }
}
