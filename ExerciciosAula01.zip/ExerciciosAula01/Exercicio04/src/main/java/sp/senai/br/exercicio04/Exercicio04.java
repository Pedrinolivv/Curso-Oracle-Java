/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio04;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio04 {

    public static void main(String[] args) {
        int n1 = Integer.parseInt(JOptionPane.showInputDialog("numero 1:"));
        int n2 = Integer.parseInt(JOptionPane.showInputDialog("numero 2:"));
        float div = n1/n2;
        JOptionPane.showMessageDialog(null, "O resultado da divisão de "+n1+" / "+n2+" é igual a: "+div);
    }
}
