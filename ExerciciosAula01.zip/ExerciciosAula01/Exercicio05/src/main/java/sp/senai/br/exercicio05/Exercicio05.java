/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio05;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio05 {

    public static void main(String[] args) {
       String s1 = JOptionPane.showInputDialog("Digite a frase 01:");
       String s2 = JOptionPane.showInputDialog("Digite a frase 02:");
       JOptionPane.showMessageDialog(null, s1+" "+s2);
    }
}
