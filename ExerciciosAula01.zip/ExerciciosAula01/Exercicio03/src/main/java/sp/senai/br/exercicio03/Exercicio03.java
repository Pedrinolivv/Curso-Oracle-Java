

package sp.senai.br.exercicio03;

import javax.swing.JOptionPane;

public class Exercicio03 {

    public static void main(String[] args) {
        int n1 = Integer.parseInt(JOptionPane.showInputDialog("numero 1:"));
        int n2 = Integer.parseInt(JOptionPane.showInputDialog("numero 2:"));
        int mult = n1*n2;
        JOptionPane.showMessageDialog(null, "O resultado da multiplicação de "+n1+" x "+n2+" é igual a: "+mult);
    }
}
