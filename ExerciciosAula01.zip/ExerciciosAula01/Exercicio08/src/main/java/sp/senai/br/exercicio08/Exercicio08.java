/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio08;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio08 {

    public static void main(String[] args) {
       float altura = Float.parseFloat(JOptionPane.showInputDialog("Digite a altura em metros: "));
       float largura = Float.parseFloat(JOptionPane.showInputDialog("Digite a largura em metros: "));
       float area = largura * altura;
       float perimetro = largura*2 + altura*2;
       JOptionPane.showMessageDialog(null, "A area desse retangulo é igual a: "+area+"m² e o seu perimetro é igual a: "+perimetro);
    }
}
