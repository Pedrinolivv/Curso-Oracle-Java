/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio06;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio06 {

    public static void main(String[] args) {
        float fCelcios = Float.parseFloat(JOptionPane.showInputDialog("Digite a temperatura em ° Celcios:"));
        float fah = (fCelcios * 9/5)+32;
        JOptionPane.showMessageDialog(null, "O valor de "+fCelcios+" em ° Fahrenheit. é igual ah: "+fah);
    }
}
