

package sp.senai.br.exercicio01;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Exercicio01 {

    public static void main(String[] args) {
       String sNome = JOptionPane.showInputDialog("Digite o nome");
       String sSobrenome = JOptionPane.showInputDialog("Digite o sobrenome:");
       int iIdade = Integer.parseInt(JOptionPane.showInputDialog("Dgite a Idade"));
       JOptionPane.showMessageDialog(null, "Seja bem-vindo "+sNome+" "+sSobrenome+", a sua idade é: "+iIdade+" anos.");
       
       
    }
}