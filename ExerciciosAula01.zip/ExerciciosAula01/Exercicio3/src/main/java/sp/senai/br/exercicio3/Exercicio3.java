/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio3;

/**
 *
 * @author aluno
 */
public class Exercicio3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
