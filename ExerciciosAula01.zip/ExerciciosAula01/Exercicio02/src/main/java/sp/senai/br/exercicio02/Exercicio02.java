

package sp.senai.br.exercicio02;

import javax.swing.JOptionPane;

public class Exercicio02 {

    public static void main(String[] args) {
       int n1 =  Integer.parseInt(JOptionPane.showInputDialog("numero 1:"));
       int n2 =  Integer.parseInt(JOptionPane.showInputDialog("numero 2:"));
       int n3 =  Integer.parseInt(JOptionPane.showInputDialog("numero 3:"));
       int n4 =  Integer.parseInt(JOptionPane.showInputDialog("numero 4:"));
       int n5 =  Integer.parseInt(JOptionPane.showInputDialog("numero 5:"));
       
       int soma = n1+n2+n3+n4+n5;
       
       JOptionPane.showMessageDialog(null, "A soma dos numeros digitados é de: "+soma);
    }
}
