/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio09;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio09 {

    public static void main(String[] args) {
       float raio = Float.parseFloat(JOptionPane.showInputDialog("Digite o raio do circulo"));
       float area = (float) (3.1415 * (raio*raio));
       float circu = (float) ((2 * 3.1415) * raio);
       JOptionPane.showMessageDialog(null, "O valor da area é de: "+area+" e a sua circunferencia é de: "+circu);
       
    }
}
