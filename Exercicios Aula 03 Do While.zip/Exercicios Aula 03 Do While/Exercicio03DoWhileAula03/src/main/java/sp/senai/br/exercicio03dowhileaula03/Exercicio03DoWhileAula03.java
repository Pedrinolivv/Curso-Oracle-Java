
package sp.senai.br.exercicio03dowhileaula03;

import javax.swing.JOptionPane;

public class Exercicio03DoWhileAula03 {
       
    public static void main(String[] args) {
       int soma = 0; 
        do{
             soma += Integer.parseInt(JOptionPane.showInputDialog("Dgite o numero para fazer a soma Valor atual: "+soma));

        }while(soma < 100);
        JOptionPane.showMessageDialog(null, "A soma chegou a 100");
     }
}
