
package sp.senai.br.exercicios01aula03while;

import javax.swing.JOptionPane;

public class Exercicios01Aula03While {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Digite a senha");
        String senha = "senha123";
        String tentativa = null;
        int cont = 2;
        while(cont>=0){
            tentativa = JOptionPane.showInputDialog("Digite a senha:");
            if (tentativa.equals(senha)){
                JOptionPane.showMessageDialog(null, "Login bem-sucedido!");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Senha Incorreta! Tentativas restantes "+cont);
                cont --;
            }
        }
    }
}
