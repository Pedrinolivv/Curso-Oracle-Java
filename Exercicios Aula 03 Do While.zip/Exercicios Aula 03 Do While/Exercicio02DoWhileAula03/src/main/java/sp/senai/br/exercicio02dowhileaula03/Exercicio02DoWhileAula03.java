
package sp.senai.br.exercicio02dowhileaula03;

import javax.swing.JOptionPane;

public class Exercicio02DoWhileAula03 {

    public static void main(String[] args) {
        int num;
        do{
              num = Integer.parseInt(JOptionPane.showInputDialog("Digite um numero de 1 a 100:"));
                  
        } while (num > 100 || num < 0);
        JOptionPane.showMessageDialog(null, "Numero Valido!");
    }
}
