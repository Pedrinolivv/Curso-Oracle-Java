/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sp.senai.br.exercicio01dowhileaula03;

import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class Exercicio01DoWhileAula03 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Uma contagem de 10 a 1 bem simples!");
        int contador = 10;
        do {
            System.out.println(contador);
            contador --;
        }while (contador >= 1);
        
    }
}
