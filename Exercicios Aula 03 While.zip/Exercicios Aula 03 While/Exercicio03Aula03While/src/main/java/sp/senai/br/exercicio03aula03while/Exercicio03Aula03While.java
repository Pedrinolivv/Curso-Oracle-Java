package sp.senai.br.exercicio03aula03while;

import javax.swing.JOptionPane;

public class Exercicio03Aula03While {

    public static void main(String[] args) {
        float fSaldo = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor do saldo inicial"));
        while (fSaldo > 0) {
            float saque = 0;
            int i = JOptionPane.showConfirmDialog(null, "Quer realizar um saque?");
            
               if (i == JOptionPane.YES_OPTION) {
                saque = Float.parseFloat(JOptionPane.showInputDialog("Valor do Saque:"));
                 if (saque < fSaldo) {
                    fSaldo = fSaldo - saque;
                    JOptionPane.showMessageDialog(null, "Saque Realizado! Valor restante = " + fSaldo);
                } else {
                    JOptionPane.showMessageDialog(null, "Impossivel realizar o saque! Saldo insuficiente ");
                }
               }

            if (i == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "Sessão finalizzada! Saldo resultante = " + fSaldo);
                break;
            }
            if (i == JOptionPane.CANCEL_OPTION) {
                JOptionPane.showMessageDialog(null, "Sessão finalizzada! Saldo resultante = " + fSaldo);
                break;
            }
        
        }
    }
}
