
package sp.senai.br.exercicio02aula03while;

import javax.swing.JOptionPane;

public class Exercicio02Aula03While {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Jogo da Adivinha!");
        int p1 = Integer.parseInt(JOptionPane.showInputDialog("Escolha um valor entre 1 a 100"));
        int cont = 4;
        int tentativa = 0;
        while (cont >= 0){
            tentativa = Integer.parseInt(JOptionPane.showInputDialog("Qual o numero escolhido pelo P1?"));
            if ( p1 == tentativa ){
                JOptionPane.showMessageDialog(null, "O Player 2 acertou o numero é "+p1);
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Você errou! Tentativas restantes: "+ cont);
                cont --;
            }
        }
        if (cont == 0){
            JOptionPane.showMessageDialog(null, "O Player 1 Venceu! O numero escolhido foi o "+p1);
        }
    }
}
